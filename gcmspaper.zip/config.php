<?php

////////////////////
// Important ! These must be filled in correctly.
// Database details are required to use this script.

$HOST = "localhost"; // If you don't know what your host is, it's safe to leave it localhost
$USERNAME = "root"; // Database name
$PASSWORD = ""; // Username
$DB = "spapergcm"; // Password

define("GOOGLE_API_KEY", "AIzaSyCXBsGnoJG53gjoSyDpW2WQBws5L1NDxF4"); // Google API key

?>