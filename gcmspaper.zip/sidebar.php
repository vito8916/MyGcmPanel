<div id="menu" class="hidden-phone hidden-print">

                <!-- Scrollable menu wrapper with Maximum height -->
                <div class="slim-scroll" data-scroll-height="800px">

                    <!-- Sidebar Profile -->
                    <span class="profile">
                    <img alt="" class="media" width="50px" height="50px" src="./assets/images/ic_launcher-web.png">
                        <span>
                            <strong>Welcome</strong>
                            <a href="#" ><?php echo $db->GetUserName(); ?></a>
                        </span>
                    </span>
              
                    <!-- Regular Size Menu -->
                    <ul style="background-color: #EEEEEE">


                        <!-- Menu Regular Item -->
                        <li class="glyphicons display dashbord"><a href="./dashbord.php"><i></i><span>Dashboard</span></a></li>
                       <li class="glyphicons user users"><a href="./users.php"><i></i><span>Users</span></a></li>
                       <li class="glyphicons bell notif"><a href="./notifications.php"><i></i><span>Notifications</span></a></li>
                       <li class="glyphicons charts reports"><a href="./reports.php"><i></i><span>Reports</span></a></li>
			<li class="glyphicons check categories"><a href="./categories.php"><i></i><span>Categories</span></a></li>
                        
                    <div class="clearfix"></div>
				


                </div>
                <!-- // Scrollable Menu wrapper with Maximum Height END -->

            </div>